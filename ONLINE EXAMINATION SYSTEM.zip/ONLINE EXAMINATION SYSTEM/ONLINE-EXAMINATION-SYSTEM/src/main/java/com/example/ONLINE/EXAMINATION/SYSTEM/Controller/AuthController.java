package com.example.ONLINE.EXAMINATION.SYSTEM.Controller;

import com.example.ONLINE.EXAMINATION.SYSTEM.Model.User;
import com.example.ONLINE.EXAMINATION.SYSTEM.Services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class AuthController{

    @Autowired
    private UserService userService;

    @GetMapping("/registerPage")
    public String openRegisterPage(Model model){
        model.addAttribute("user", new User());
        return "register";
    }

    @PostMapping("/registerPage")
    public String submitRegisterForm(@ModelAttribute("user") User user, Model model){
        boolean status = userService.registerUser(user);

        if (status){
            model.addAttribute("success","Successfully register");
        }
        else{
            model.addAttribute("error", "User not register due to some error");
        }

        return "register";
    }

    @GetMapping("/loginPage")
    public String openLoginPage(Model model){
        model.addAttribute("user", new User());
        return "login";
    }

    @PostMapping("/loginPage")
    public String submitLoginForm(@ModelAttribute User user, Model model){
        User validUser = userService.loginUser(user.getUsername(), user.getPassword());

        if (validUser != null){
            if (validUser.getRole().equalsIgnoreCase("ADMIN")) {
                return "redirect:/admin/dashboard";
            } else if (validUser.getRole().equalsIgnoreCase("STUDENT")) {
                return "redirect:/student/dashboard";
            }
        }

        model.addAttribute("error", "Username or Password is incorrect!");
        return "login";
    }

}
