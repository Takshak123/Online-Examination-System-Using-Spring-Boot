package com.example.ONLINE.EXAMINATION.SYSTEM.Controller;

import com.example.ONLINE.EXAMINATION.SYSTEM.Model.Exam;
import com.example.ONLINE.EXAMINATION.SYSTEM.Services.ExamServices;
import com.example.ONLINE.EXAMINATION.SYSTEM.Services.QuestionService;


import com.example.ONLINE.EXAMINATION.SYSTEM.Services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@Controller
public class StudentController {

    @Autowired
    private QuestionService questionService;

    @Autowired
    private UserService userService;

    @Autowired
    private ExamServices examServices;

    @GetMapping("/student/dashboard")
    public String showStudentDashboard() {
        return "studentDashboard";
    }

    @GetMapping("/student/viewAvailableExams")
    public String viewAvailableExam(Model model){
        List<Exam> exam = examServices.getAllExam();
        model.addAttribute("exams", exam);
        return "viewAvailableExam";
    }
}
