package com.example.ONLINE.EXAMINATION.SYSTEM.Controller;
import com.example.ONLINE.EXAMINATION.SYSTEM.Model.Question;
import com.example.ONLINE.EXAMINATION.SYSTEM.Model.User;
import com.example.ONLINE.EXAMINATION.SYSTEM.Services.QuestionService;
import com.example.ONLINE.EXAMINATION.SYSTEM.Services.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class AdminController {

    @Autowired
    private QuestionService questionService;

    @Autowired
    private UserService userService;

    @GetMapping("/admin/dashboard")
    public String showAdminDashboard() {
        return "adminDashboard";
    }

    @GetMapping("/admin/add-questions")
    public String questionForm(Model model){
        model.addAttribute("question", new Question());
        return "questionForm";
    }

    @PostMapping("/admin/add-questions")
    public String addNewExam(@ModelAttribute Question question){
        questionService.saveQuestion(question);
        return "redirect:/admin/dashboard";
    }

    @GetMapping("/admin/manageQuestion")
    public String manageQuestion(Model model){
        List<Question> questions = questionService.getAllQuestion();
        model.addAttribute("question",questions);
        return "manageQuestion";
    }

    @GetMapping("/admin/edit-question/{id}")
    public String editQuestion(@PathVariable Long id, Model model){
        Question question = questionService.getQuestionById(id);
        model.addAttribute("question", question);
        return "redirect:/admin/add-questions";
    }

    @GetMapping("/admin/delete-question/{id}")
    public String deleteQuestion(@PathVariable Long id){
        questionService.deleteQuestionById(id);
        return "redirect:/admin/manageQuestion";
    }

    @GetMapping("/admin/viewStudents")
    public String viewStudent(Model model){
        List<User> student = userService.getAllStudent();
        model.addAttribute("student", student);
        return "viewStudents";
    }

}
