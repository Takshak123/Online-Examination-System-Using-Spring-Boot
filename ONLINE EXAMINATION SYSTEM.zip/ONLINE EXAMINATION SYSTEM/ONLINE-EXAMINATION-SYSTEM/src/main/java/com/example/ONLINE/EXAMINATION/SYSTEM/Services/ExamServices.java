package com.example.ONLINE.EXAMINATION.SYSTEM.Services;

import com.example.ONLINE.EXAMINATION.SYSTEM.Model.Exam;
import com.example.ONLINE.EXAMINATION.SYSTEM.Repository.ExamRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ExamServices {

    @Autowired
    private ExamRepository examRepository;

    public Exam saveExam(Exam exam) {
        return examRepository.save(exam);
    }

    public List<Exam> getAllExam() {
       return examRepository.findAll();
    }
}
