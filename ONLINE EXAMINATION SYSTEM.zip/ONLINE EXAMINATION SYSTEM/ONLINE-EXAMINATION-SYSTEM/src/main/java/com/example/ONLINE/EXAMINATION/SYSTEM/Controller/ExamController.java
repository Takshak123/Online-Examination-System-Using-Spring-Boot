package com.example.ONLINE.EXAMINATION.SYSTEM.Controller;

import com.example.ONLINE.EXAMINATION.SYSTEM.Model.Exam;
import com.example.ONLINE.EXAMINATION.SYSTEM.Model.Question;
import com.example.ONLINE.EXAMINATION.SYSTEM.Model.Result;
import com.example.ONLINE.EXAMINATION.SYSTEM.Services.ExamServices;
import com.example.ONLINE.EXAMINATION.SYSTEM.Services.QuestionService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class ExamController {

    @Autowired
    private ExamServices examServices;

    @Autowired
    private QuestionService questionService;


    @GetMapping("/admin/save-exam")
    public String showExamForm(Model model){
        model.addAttribute("exam", new Exam());
        return "examForm";
    }

    @PostMapping("/admin/save-exam")
    public String saveExam(@ModelAttribute Exam exam){
        examServices.saveExam(exam);
        return "redirect:/admin/add-questions";
    }

    @GetMapping("/student/next-question")
    public String examStart(Model model){
        List<Question> questions = questionService.getAllQuestion();
        model.addAttribute("question", questions.get(0));
        model.addAttribute("questionNumber",1);
        return "startExam";
    }

    @PostMapping("/student/next-question")
    public String nextQuestion(@RequestParam(value = "selectedAnswer", required = false) String selectedAnswer,
                               @RequestParam(value = "questionId", required = false) Long questionId,
                               @RequestParam("questionNumber") int questionNumber,
                               HttpSession session,
                               Model model) {

        List<Question> questions = questionService.getAllQuestion();

        // Get or create result
        Result result = (Result) session.getAttribute("currentResult");
        if (result == null) {
            result = new Result();
            result.setStudentId((Long) session.getAttribute("studentId"));
            result.setTotalQuestions(0);
            result.setCorrectAnswers(0);
            result.setTotalMarks(0);
        }

        // Evaluate previous answer
        if (questionId != null && selectedAnswer != null) {
            Question previousQuestion = questionService.getQuestionById(questionId);

            if (previousQuestion != null) {
                result.setTotalQuestions(result.getTotalQuestions() + 1);

                if (previousQuestion.getCorrectAnswer().equalsIgnoreCase(selectedAnswer)) {
                    result.setCorrectAnswers(result.getCorrectAnswers() + 1);
                    result.setTotalMarks(result.getTotalMarks() + 1);
                }
            }
        }

        // Store result back in session
        session.setAttribute("currentResult", result);

        // Show next question or result page
        if (questionNumber < questions.size()) {
            Question nextQuestion = questions.get(questionNumber);
            model.addAttribute("question", nextQuestion);
            model.addAttribute("questionNumber", questionNumber + 1);
            return "startExam";
        } else {
            return "redirect:/student/result";
        }
    }
}
