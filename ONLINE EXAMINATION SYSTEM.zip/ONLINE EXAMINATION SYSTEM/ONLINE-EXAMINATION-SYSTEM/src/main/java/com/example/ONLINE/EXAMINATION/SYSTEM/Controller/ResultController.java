package com.example.ONLINE.EXAMINATION.SYSTEM.Controller;

import com.example.ONLINE.EXAMINATION.SYSTEM.Model.Result;
import com.example.ONLINE.EXAMINATION.SYSTEM.Services.QuestionService;
import com.example.ONLINE.EXAMINATION.SYSTEM.Services.ResultService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@Controller
public class ResultController {

    @Autowired
    private ResultService resultService;

    @Autowired
    private QuestionService questionService;

    @GetMapping("/create")
    public String showCreateResultForm(Model model){
        model.addAttribute("result", new Result());
        return "createResult";
    }

    @GetMapping("/all")
    public String viewAllResult(Model model){
        List<Result> results = resultService.getAllResult();
        model.addAttribute("results", results);
        return "viewResults";
    }

    @GetMapping("/user/{userId}")
    public String viewResultByUserId(@PathVariable Long userId, Model model){
        List<Result> results = resultService.getResultByUserId(userId);
        model.addAttribute("results", results);
        return "viewResults";
    }

    @GetMapping("/student/result")
    public String showResultPage(HttpSession session, Model model) {
        Result result = (Result) session.getAttribute("currentResult");

        if (result == null) {
            return "redirect:/student/dashboard";
        }

        model.addAttribute("result", result);
        return "resultPage";
    }

}
