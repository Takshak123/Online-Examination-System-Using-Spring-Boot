package com.example.ONLINE.EXAMINATION.SYSTEM.Services;

import com.example.ONLINE.EXAMINATION.SYSTEM.Model.Result;
import com.example.ONLINE.EXAMINATION.SYSTEM.Repository.ResultRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class ResultService {

    @Autowired
    private ResultRepository resultRepository;

    public List<Result> getAllResult() {
        return resultRepository.findAll();
    }

    public List<Result> getResultByUserId(Long userId) {
        return resultRepository.findUserById(userId);
    }

    // Overloaded method to save detailed result
    public void saveResult(Long userId, int score, int totalQuestions, int correctAnswers, int totalMarks) {
        Result result = new Result();
        result.setUserId(userId);
        result.setScore(score);
        result.setTotalQuestions(totalQuestions);
        result.setCorrectAnswers(correctAnswers);
        result.setTotalMarks(totalMarks);
        result.setLocalDateTime(LocalDateTime.now());

        resultRepository.save(result);
    }

    // Original method (optional — can keep for backward compatibility)
    public void saveResult(Long userId, int score) {
        Result result = new Result();
        result.setUserId(userId);
        result.setScore(score);
        result.setLocalDateTime(LocalDateTime.now());
        resultRepository.save(result);
    }

    public void saveFinalResult(Result result) {
        resultRepository.save(result);
    }
}
